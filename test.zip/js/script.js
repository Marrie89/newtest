$(function() {


  $(".slider").bxSlider({
      speed:1000,
      pager:false,
      slideWidth: 1800,
      controls:true,
	  infiniteLoop:false
  });
  $(".logos").bxSlider({
      speed:1000,
      pager:false,
      controls:true,
	  infiniteLoop:false
  });
});